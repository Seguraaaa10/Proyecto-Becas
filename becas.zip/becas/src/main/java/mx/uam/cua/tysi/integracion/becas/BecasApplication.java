package mx.uam.cua.tysi.integracion.becas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BecasApplication {

	public static void main(String[] args) {
		SpringApplication.run(BecasApplication.class, args);
	}

}
